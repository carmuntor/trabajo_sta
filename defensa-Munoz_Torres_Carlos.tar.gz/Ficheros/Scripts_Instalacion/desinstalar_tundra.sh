#!/bin/bash

# Ruta del directorio tundra-nat64
TUNDRA_DIR="/home/dit/tundra-nat64"

# Ruta del directorio home del usuario
HOME_DIR="/home/dit"

# Ejecutar make clean en el directorio tundra-nat64
echo "Desinstalando tundra-nat64..."
cd "$TUNDRA_DIR" || exit
make clean

# Eliminar archivos .c y .h del sistema
echo "Eliminando archivos .c y .h del sistema..."
find "$HOME_DIR" -type f \( -name "*.c" -o -name "*.h" \) -delete

# Eliminar el repositorio tundra-nat64 completo
echo "Eliminando el repositorio tundra-nat64..."
rm -rf "$TUNDRA_DIR"

echo "Desinstalación completada."
