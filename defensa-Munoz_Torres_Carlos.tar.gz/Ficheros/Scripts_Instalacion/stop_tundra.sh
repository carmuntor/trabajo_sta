#!/bin/bash

TUNDRA_CONFIG_FILE="./tundra-nat64.example.conf"
WAN_INTERFACE_NAME="eth0"

# Eliminamos la regla NAT66
ip6tables -t nat -D POSTROUTING -d 64:ff9b::/96 -o tundra -j SNAT --to-source=fd00:6464::2

# Eliminamos la regla NAT44
iptables -t nat -D POSTROUTING -o $WAN_INTERFACE_NAME -j MASQUERADE

# Eliminamos la interfaz tundra
cd /home/dit/tundra-nat64/
./tundra-nat64 --config-file=$TUNDRA_CONFIG_FILE rmtun
