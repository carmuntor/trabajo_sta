#!/bin/bash

# Verificar si se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    echo "Este script debe ejecutarse como root."
    exit 1
fi

# Ruta al archivo sysctl.conf original
archivo_sysctl="/etc/sysctl.conf"

# Ruta al directorio de configuración sysctl
config_dir="/home/dit/config_sysctl"

# Ruta al repositorio de configuraciones originales
repo_original="/home/dit/sysctl_original"

# Verificar si el archivo sysctl.conf existe en el directorio de configuración sysctl
if [ -f "$repo_original/sysctl.conf.bak" ]; then
    # Mover el archivo sysctl.conf al directorio /home/dit/config_sysctl
    mv "$archivo_sysctl" "$config_dir/sysctl.conf"

    # Mover el archivo original desde el repositorio
    mv "$repo_original/sysctl.conf.bak" "$archivo_sysctl"

    echo "La configuración original de sysctl.conf ha sido restaurada."
else
    echo "Error: El archivo de configuración sysctl.conf no existe en el directorio de configuración sysctl."
fi
