#!/bin/bash

# Verifica que el script se esté ejecutando como superusuario (root)
if [[ $EUID -ne 0 ]]; then
   echo "Este script debe ser ejecutado como superusuario (root)." 
   exit 1
fi

# Crea el archivo de unidad Systemd para Wrapsix
unit_file="/etc/systemd/system/wrapsix.service"
echo "[Unit]
Description=Wrapsix Service
After=network.target

[Service]
ExecStart=/home/dit/wrapsix-0.2.1/src/wrapsix /home/dit/wrapsix-0.2.1/wrapsix.conf
Restart=always

[Install]
WantedBy=multi-user.target" > "$unit_file"

# Recarga la configuración de Systemd
systemctl daemon-reload

# Habilita el servicio para que inicie automáticamente con el arranque del sistema
systemctl enable wrapsix.service

# Inicia el servicio
systemctl start wrapsix.service

echo "Configuración de Wrapsix completada. El servicio se iniciará automáticamente con el arranque del sistema."

 
