#!/bin/bash

# Verificar si se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    echo "Este script debe ejecutarse como root."
    exit 1
fi

# Ruta al archivo interfaces original
archivo_interfaces="/etc/network/interfaces"

# Ruta al directorio de configuración eth1
config_dir="/home/dit/config_eth1_hostIPv4"

# Ruta al repositorio de configuraciones originales
repo_original="/home/dit/interfaces_original_eth1_hostIPv4"

# Verificar si el archivo interfaces existe en el directorio de configuración eth1
if [ -f "$repo_original/interfaces.bak" ]; then
    # Mover el archivo interfaces al directorio /home/dit/config_eth1
    mv "$archivo_interfaces" "$config_dir/interfaces"

    # Mover el archivo original desde el repositorio
    mv "$repo_original/interfaces.bak" "$archivo_interfaces"

    echo "La configuración original de interfaces ha sido restaurada."
else
    echo "Error: El archivo de configuración interfaces no existe en el directorio de configuración eth1."
fi
