#!/bin/bash

# Verifica que el script se esté ejecutando como superusuario (root)
if [[ $EUID -ne 0 ]]; then
   echo "Este script debe ser ejecutado como superusuario (root)." 
   exit 1
fi

# Crea el archivo de unidad Systemd
unit_file="/etc/systemd/system/tundra.service"
echo "[Unit]
Description=Tundra Service
After=network.target

[Service]
ExecStart=/home/dit/trabajo_sta/Ficheros/Scripts_Instalacion/start_tundra.sh
Restart=always

[Install]
WantedBy=multi-user.target" > "$unit_file"

# Recarga la configuración de Systemd
systemctl daemon-reload

# Habilita el servicio para que inicie automáticamente con el arranque del sistema
systemctl enable tundra.service

# Inicia el servicio
systemctl start tundra.service

echo "Configuración de Tundra completada. El servicio se iniciará automáticamente con el arranque del sistema."
