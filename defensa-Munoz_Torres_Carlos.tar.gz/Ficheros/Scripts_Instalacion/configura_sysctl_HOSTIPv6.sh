#!/bin/bash

# Verificar si se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    echo "Este script debe ejecutarse como root."
    exit 1
fi

# Definir las nuevas configuraciones
nuevas_configuraciones="
# Kernel sysctl configuration file for Red Hat Linux
#
# For binary values, 0 is disabled, 1 is enabled.  See sysctl(8) and
# sysctl.conf(5) for more details.

# Controls IP packet forwarding
net.ipv4.ip_forward = 0

# Controls source route verification
net.ipv4.conf.default.rp_filter = 1

# Do not accept source routing
net.ipv4.conf.default.accept_source_route = 0

# Controls the System Request debugging functionality of the kernel
kernel.sysrq = 0

# Controls whether core dumps will append the PID to the core filename.
# Useful for debugging multi-threaded applications.
kernel.core_uses_pid = 1

# Deactivate IPv6
net.ipv6.conf.all.disable_ipv6 = 0
net.ipv6.conf.default.disable_ipv6 = 0

# PINGs
net.ipv4.icmp_echo_ignore_all = 0
net.ipv4.icmp_echo_ignore_broadcasts = 0
"

# Ruta al archivo sysctl.conf original
archivo_sysctl="/etc/sysctl.conf"

# Ruta al repositorio de configuraciones originales
repo_original="/home/dit/sysctl_original_HOSTIPv6"

# Ruta al directorio de configuración sysctl_HOSTIPv6
config_dir="/home/dit/sysctl_HOSTIPv6"

# Verificar si el archivo sysctl.conf existe
if [ -f "$archivo_sysctl" ]; then
    # Crear una copia de seguridad en el repositorio original
    mkdir -p "$repo_original"
    cp "$archivo_sysctl" "$repo_original/sysctl.conf.bak"

    # Crear el directorio de configuración sysctl_HOSTIPv6 si no existe
    mkdir -p "$config_dir"

    # Crear el nuevo archivo sysctl.conf en el directorio de configuración sysctl_HOSTIPv6
    echo "$nuevas_configuraciones" > "$config_dir/sysctl.conf"

    # Mover el nuevo archivo sysctl.conf al directorio /etc
    mv "$config_dir/sysctl.conf" "$archivo_sysctl"

    echo "El archivo de configuración sysctl.conf ha sido actualizado."
else
    echo "Error: El archivo de configuración sysctl.conf no existe en la ruta especificada."
fi

