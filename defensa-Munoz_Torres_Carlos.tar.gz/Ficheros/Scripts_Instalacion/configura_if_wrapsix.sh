#!/bin/bash

# Verificar si se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    echo "Este script debe ejecutarse como root."
    exit 1
fi

# Definir las nuevas configuraciones
nuevas_configuraciones="# interfaces(5) file used by ifup(8) and ifdown(8)
#auto lo
#iface lo inet loopback
#
# Interfaz integrada en placa (DHCP)
auto eth0
iface eth0 inet dhcp
# Interfaz PCI (Estática)
auto eth1
iface eth1 inet static
        address 192.168.8.64
iface eth1 inet6 static
        address 2001:db8::1/64"

# Ruta al archivo interfaces original
archivo_interfaces="/etc/network/interfaces"

# Ruta al repositorio de configuraciones originales
repo_original="/home/dit/interfaces_original"

# Ruta al directorio de configuración wrapsix
config_dir="/home/dit/config_wrapsix"

# Verificar si el archivo interfaces existe
if [ -f "$archivo_interfaces" ]; then
    # Crear una copia de seguridad en el repositorio original
    mkdir -p "$repo_original"
    cp "$archivo_interfaces" "$repo_original/interfaces.bak"

    # Crear el directorio de configuración wrapsix si no existe
    mkdir -p "$config_dir"

    # Crear el nuevo archivo interfaces en el directorio de configuración wrapsix
    echo "$nuevas_configuraciones" > "$config_dir/interfaces"

    # Mover el nuevo archivo interfaces al directorio /etc/network
    mv "$config_dir/interfaces" "$archivo_interfaces"

    echo "El archivo de configuración interfaces ha sido actualizado."
else
    echo "Error: El archivo de configuración interfaces no existe en la ruta especificada."
fi
