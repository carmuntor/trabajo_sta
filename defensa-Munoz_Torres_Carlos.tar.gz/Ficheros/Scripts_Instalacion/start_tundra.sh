#!/bin/bash

function exit_with_error() {
  echo "ERROR: $1"
  exit 1
}

TUNDRA_CONFIG_FILE="/home/dit/tundra-nat64/tundra-nat64.example.conf"
WAN_INTERFACE_NAME="eth0"

# Establecemos la ruta del ejecutable
TUNDRA_EXECUTABLE="/home/dit/tundra-nat64/tundra-nat64"

# Crea una nueva interfaz de red TUN
"${TUNDRA_EXECUTABLE}" --config-file="${TUNDRA_CONFIG_FILE}" mktun || exit_with_error "Fallo al crear la interfaz TUN."

# Configura la interfaz TUN
ip link set dev tundra up || exit_with_error "Fallo al activar la interfaz TUN."
ip addr add 192.168.64.254/24 dev tundra || exit_with_error "Fallo al configurar la dirección IPv4 de la interfaz TUN."
ip -6 addr add fd00:6464::fffe/64 dev tundra || exit_with_error "Fallo al configurar la dirección IPv6 de la interfaz TUN."
ip -6 route add 64:ff9b::/96 dev tundra || exit_with_error "Fallo al configurar la ruta IPv6 de la interfaz TUN."

# Configura NAT66 para IPv6
ip6tables -t nat -A POSTROUTING -d 64:ff9b::/96 -o tundra -j SNAT --to-source=fd00:6464::2 || exit_with_error "Fallo al configurar NAT66 para IPv6."

# Realiza NAT44 en todos los paquetes que van a Internet
iptables -t nat -A POSTROUTING -o $WAN_INTERFACE_NAME -j MASQUERADE || exit_with_error "Fallo al configurar NAT44 para los paquetes que van a Internet."

# Inicia el traductor NAT64 (para terminarlo, envía SIGTERM, SIGINT o SIGHUP al proceso)
"${TUNDRA_EXECUTABLE}" --config-file="${TUNDRA_CONFIG_FILE}" translate
