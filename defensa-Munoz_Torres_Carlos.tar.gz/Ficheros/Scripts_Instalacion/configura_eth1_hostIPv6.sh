#!/bin/bash

# Verificar si se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    echo "Este script debe ejecutarse como root."
    exit 1
fi

# Definir las nuevas configuraciones
nuevas_configuraciones="DEVICE=eth1
ONBOOT=yes
BOOTPROTO=none
IPV6INIT=yes
IPV6ADDR=2001:db8::2/64
IPV6_DEFAULTGW=2001:db8::1
NM_CONTROLLED=\"no\""

# Ruta al archivo ifcfg-eth1 original
archivo_eth1="/etc/sysconfig/network-scripts/ifcfg-eth1"

# Ruta al repositorio de configuraciones originales
repo_original="/home/dit/interfaz_eth1_original_hostIPv6"

# Ruta al directorio de configuración eth1_hostIPv6
config_dir="/home/dit/config_eth1_hostIPv6"

# Verificar si el archivo ifcfg-eth1 existe
if [ -f "$archivo_eth1" ]; then
    # Crear una copia de seguridad en el repositorio original
    mkdir -p "$repo_original"
    cp "$archivo_eth1" "$repo_original/ifcfg-eth1.bak"

    # Crear el directorio de configuración eth1_hostIPv6 si no existe
    mkdir -p "$config_dir"

    # Crear el nuevo archivo ifcfg-eth1 en el directorio de configuración eth1_hostIPv6
    echo "$nuevas_configuraciones" > "$config_dir/ifcfg-eth1"

    # Mover el nuevo archivo ifcfg-eth1 al directorio /etc/sysconfig/network-scripts
    mv "$config_dir/ifcfg-eth1" "$archivo_eth1"

    echo "El archivo de configuración ifcfg-eth1 ha sido actualizado."
else
    echo "Error: El archivo de configuración ifcfg-eth1 no existe en la ruta especificada."
fi
