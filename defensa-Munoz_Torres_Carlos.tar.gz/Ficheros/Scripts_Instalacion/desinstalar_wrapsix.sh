#!/bin/bash

# Ruta del directorio wrapsix
WRAPSIX_DIR="/home/dit/wrapsix-0.2.1"

# Ruta del directorio home del usuario
HOME_DIR="/home/dit"

# Ejecutar make clean en el directorio wrapsix
echo "Desinstalando wrapsix..."
cd "$WRAPSIX_DIR" || exit
make clean

# Eliminar el directorio wrapsix completo
echo "Eliminando el directorio wrapsix..."
rm -rf "$WRAPSIX_DIR"

echo "Desinstalación de wrapsix completada."
