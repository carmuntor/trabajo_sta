#!/bin/bash

# Verificar si el script se está ejecutando como superusuario
if [[ $EUID -ne 0 ]]; then
    echo "Este script debe ejecutarse como superusuario." 
    exit 1
fi

# URL del repositorio Git
REPO_URL=https://github.com/vitlabuda/tundra-nat64

# Directorio de clonación
DIR_CLONACION=/home/dit/tundra-nat64

# Nombre del ejecutable después de la compilación
EJECUTABLE=tundra-nat64

# Clonar el repositorio Git
echo "Clonando el repositorio..."
git clone "$REPO_URL" "$DIR_CLONACION"

# Verificar si la clonación fue exitosa
if [ $? -ne 0 ]; then
    echo "Error al clonar el repositorio. Verifica la URL del repositorio y los permisos."
    exit 1
fi

# Compilar el código fuente
echo "Compilando el código fuente..."
cd "$DIR_CLONACION"
# Comandos de compilación (puede ser make, cmake, u otros)
gcc -Wall -Wextra -pthread -std=c11 -O3 -flto -o tundra-nat64 src/t64_*.c
# Verificar si la compilación fue exitosa
if [ $? -ne 0 ]; then
    echo "Error durante la compilación. Verifica las dependencias y los comandos de compilación."
    exit 1
fi

# Verificar si el ejecutable existe
if [ -x "$EJECUTABLE" ]; then
    echo "El ejecutable se ha creado correctamente. Puedes ejecutarlo con ./$EJECUTABLE."
else
    echo "Error al crear el ejecutable. Verifica los comandos de compilación y la configuración."
fi
