#!/bin/bash

#Verificamos si el script se está ejecutando como root
if [[ $EUID -ne O ]]; then
    echo "Este script debe ejecutarse como root."
    exit 1
fi

#Descargamos y descomprimimos el fichero con curl
echo "Descargando wrapsix..."
curl -O https://www.semirocket.science/projects/wrapsix/download/wrapsix-0.2.1.tar.bz2
tar -xjvf wrapsix-0.2.1.tar.bz2
mv wrapsix-0.2.1 /home/dit/

# Eliminamos el archivo comprimido
echo "Eliminando el archivo comprimido..."
rm -rf wrapsix-0.2.1.tar.bz2

#Configuramos y compilamos wrapsix
echo "Configurando y compilando wrapsix..."
cd /home/dit/wrapsix-0.2.1
./configure
make
make install

echo "Instalación completada. Wrapsix listo para ejecutarse"

