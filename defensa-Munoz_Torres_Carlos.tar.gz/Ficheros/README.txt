En este fichero de texto vamos a especificar el uso de los distintos scripts para arrancar el servicio tanto de WrapSix como de Tundra. En ambos casos detallaremo los pasos a seguir. Resulta importante resaltar que todos los scripts se han de ejecutar en el modo administrador y previo a su uso, tenemos que darlos permisos de ejecución. Esto se puede hacer mediante el comando:

   chmod +x *.sh (en el directorio donde se encuentren los scripts)

Instalación, configuración y ejecución de Wrapsix:

     1) ./configura_sysctl.sh

Este script habilita el reenvío de paquetes tanto para IPv6 como para IPv4

     2) ./configura_if_wrapsix.sh

Mediante este script, podemos configurar las interfaces de red para el correcto funcionamiento de WrapSix
   
     3) ./instalar_wrapsix.sh

Este script realiza la instalación por código fuente del servicio WrapSix, para ello nos descargamos el paquete comprimido del servicio, lo descomprimimos y finalmente llevamos a cabo los comandos relativos a la compilación e instalación (./configure && make && make install)

     4) ./configura_wrapsix_conf.sh

Este script establece la configuración del fichero wrapsix.conf, necesaria para la ejecución de WrapSix.

     5) ./configura_wrapsix_systemd.sh

Este script nos permite arrancar el servicio con el sistema, mediante el sistema de arranque Systemd.

Una vez hemos terminado de utilizar el servicio WrapSix, realizaremos un proceso de desinstalación del servicio y eliminaremos la configuración establecida dejando la configuración original.

     6) ./desinstalar_wrapsix.sh

Para desinstalar el servicio mediante código fuente.

     7) ./devuelve_original_if_wrapsix.sh

Cambiamos el fichero de configuración de interfaces (/etc/network/interfaces) que ha utilizado para el servicio WrapSix por el que estaba antes (es decir, el fichero original).

     8) ./devuelve_sysctl_original.sh

Deshabilitamos el reenvío de paquetes tanto para IPv6 como para IPv4. Para ello, cambiamos el fichero /etc/sysctl.conf que hemos utilizado nosotros por el original.


Instalación, configuración y ejecución de Tundra:

     1) ./configura_sysctl.sh

Este script habilita el reenvío de paquetes tanto para IPv6 como para IPv4

     2) ./configura_if_tundra.sh

Mediante este script, podemos configurar las interfaces de red para el correcto funcionamiento de Tundra (fichero /etc/network/interfaces)
   
     3) ./instalar_tundra.sh

Este script realiza la instalación por código fuente del servicio Tundra, para lo cual tenemos que clonar un repositorio y llevar a cabo el correspondiente comando de compilación (Aunque en el directorio "/Otros" se ubica un Makefile que sirve tanto para la compilación como para la eliminación de ficheros binarios de ejecución.

     4) ./configura_tundra_systemd.sh

Este script nos permite arrancar el servicio con el sistema, mediante el sistema de arranque Systemd.

Una vez hemos terminado de utilizar el servicio WrapSix, realizaremos un proceso de desinstalación del servicio y eliminaremos la configuración establecida dejando la configuración original.

     5) ./stop_tundra.sh
Mediante este script, deshacemos las reglas nat establecidas y eliminamos la interfaz tundra.

     6) ./desinstalar_tundra.sh

Para desinstalar el servicio mediante código fuente.

     7) ./devuelve_original_if_tundra.sh

Cambiamos el fichero de configuración de interfaces (/etc/network/interfaces) que ha utilizado para el servicio Tundra por el que estaba antes (es decir, el fichero original).

     8) ./devuelve_sysctl_original.sh

Deshabilitamos el reenvío de paquetes tanto para IPv6 como para IPv4. Para ello, cambiamos el fichero /etc/sysctl.conf que hemos utilizado nosotros por el original.

- Configuración del cliente IPv6

     1) ./configura_sysctl_HOSTIPv6.sh

Esto lo hacemos para habilitar el protocolo IPv6 en el kernel.

     2) ./configura_eth1_hostIPv6.sh

Para configurar la interfaz eth1 del cliente IPv6

Cuando queramos dejar de ejecutar el servicio, inicializamos la configuración del Host IPv6 estableciendo la configuración original.

     3) ./devuelve_eth1_original_hostIPv6.sh

Establece la configuración original del fichero /etc/sysconfig/network-scripts/ifcfg-eth1.

     4) ./devuelve_sysctl_HOSTIPv6_original.sh

Deshabilita IPv6 en el kernel (tal y como estaba configurado)

- Configuración del cliente IPv4

     1) ./config_eth1_HOSTIPv4.sh

Configura las interfaces de red

     2) ./devuelve_eth1_original_HOSTIPv4.sh

Para establecer la configuración original del fichero /etc/network/interfaces




